package seleniumproject;

import org.openqa.selenium.By;

public class MethodSignInVerifyC {
	
	  public void verifyUserWithValidUIdBlankPwd() throws InterruptedException 
	  {
			 String expected_result="Invalid user or password";
				
			 //Verify User With Valid Id And Blank Pwd   START
			 SignInVerifyC.driver.findElement(By.linkText("Sign in")).click();
	         Thread.sleep(2000);
	         SignInVerifyC.driver.findElement(By.id("username")).sendKeys("testsample1234");
	         SignInVerifyC.driver.findElement(By.id("password")).sendKeys("");
	         Thread.sleep(2000);
	         SignInVerifyC.driver.findElement(By.name("login")).click();
	         String actual_result=SignInVerifyC.driver.findElement(By.id("flash_error")).getText();
	         
	         //NOW VALIDATE actual_result AND expected_result
	         if(actual_result.equalsIgnoreCase(expected_result)) {
	                   System.out.println("User With Valid Id And Blank Pwd TestCase    SUCCESS");
	         }
	         else {
	        	 System.out.println("FAILURE");
	         }
	  }
	  
	      

public void verifyUserWithvalidUIdPwd() throws InterruptedException {
	
    //1.Verify user signin and password   START
  
	SignInVerifyC.driver.findElement(By.linkText("Sign in")).click();
	Thread.sleep(2000);
	SignInVerifyC.driver.findElement(By.id("username")).sendKeys("testsample1234");
	SignInVerifyC.driver.findElement(By.id("password")).sendKeys("password");
    Thread.sleep(2000);

    SignInVerifyC.driver.findElement(By.name("login")).click();
  
    boolean result=SignInVerifyC.driver.findElement(By.linkText("Sign out")).isEnabled();
    if(result) {
    System.out.println("Verify user signin and password :SUCCESS");
    }
    else
    {
    System.out.println("Verify user signin and password :FAILURE");
    }
    SignInVerifyC.driver.findElement(By.linkText("Sign out")).click();
    Thread.sleep(4000);
    //1.Verify user signin and password   ENDED
    }





public void verifyUserWithvalidUIdInvalidPwd() throws InterruptedException {
	 
	 String expected_result="Invalid user or password";
	
	 //Verify User With Valid Id And Invalid Pwd   START
	 SignInVerifyC.driver.findElement(By.linkText("Sign in")).click();
    Thread.sleep(2000);
    SignInVerifyC.driver.findElement(By.id("username")).sendKeys("testsample1234");
    SignInVerifyC.driver.findElement(By.id("password")).sendKeys("a");
    Thread.sleep(2000);
    SignInVerifyC.driver.findElement(By.name("login")).click();
    String actual_result=SignInVerifyC.driver.findElement(By.id("flash_error")).getText();
    
    //NOW VALIDATE actual_result AND expected_result
    if(actual_result.equalsIgnoreCase(expected_result)) {
              System.out.println("User With Valid Id And Invalid Pwd TestCase    SUCCESS");
    }
    else {
   	 System.out.println("FAILURE");
    }
    Thread.sleep(2000);
}
}





















 